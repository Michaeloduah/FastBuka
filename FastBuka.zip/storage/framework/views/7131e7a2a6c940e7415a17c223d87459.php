

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Admin Dashboard</h1>
        <ol>
            <strong>Features</strong>
            <li>Add Categories</li> <a href="<?php echo e(route('dashboard.admin.category.index')); ?>">Category</a>
            <li>Add Products</li>  <a href="<?php echo e(route('dashboard.admin.product.index')); ?>">Product</a>  <a href="<?php echo e(route('dashboard.admin.product.create')); ?>">Add Product</a>
            <li>View Orders</li>
            <li>View Product Ordered</li>
            <li>Receive Messages</li> <a href="<?php echo e(route('dashboard.admin.inbox.index')); ?>">Inbox</a>
        </ol><br><br>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\admin\dashboard.blade.php ENDPATH**/ ?>