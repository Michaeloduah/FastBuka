

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Vendor Dashboard</h1>
        <h3 class="text-center">See all Category Details</h3>

        <h5>Category Name: <?php echo e($category->name); ?></h5>
        <img src="<?php echo e(asset('storage/' . $category->image)); ?>" width="30%" alt="" class="img-fluid img-rounded">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\vendors\category\show.blade.php ENDPATH**/ ?>