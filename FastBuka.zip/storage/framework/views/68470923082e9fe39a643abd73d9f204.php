

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>User Dashboard</strong></h1>
        <h3 class=""><strong>Search Result</strong></h3>

        <div class="my-5">
            <p>Venodrs</p>
            <ul>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($user->name); ?></li>
                    <li><?php echo e($user->email); ?></li>
                    <li><?php echo e($user->phone); ?></li>
                    <li><?php echo e($user->address); ?></li>
                    <img src="<?php echo e(asset('storage/' . $user->image)); ?>" width="20%" alt="" class="img-fluid">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <p>Foods</p>
            <ul>
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><span class="fw-bolder">Food Category:</span> <?php echo e($food->category->name); ?></li>
                    <li><span class="fw-bolder">Name:</span> <?php echo e($food->name); ?></li>
                    <li><span class="fw-bolder">Description:</span> <?php echo e($food->description); ?></li>
                    <li><span class="fw-bolder">Price:</span> <?php echo e($food->price); ?></li>
                    <li><span class="fw-bolder">Discount:</span> <?php echo e($food->discount); ?></li>
                    <li><span class="fw-bolder">Images</li>
                    <?php $__currentLoopData = $food->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="thumbnail m-5" width="15%" src="<?php echo e(asset('storage/images/foods/' . $image)); ?>"
                            alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views/dashboard/users/food/result.blade.php ENDPATH**/ ?>