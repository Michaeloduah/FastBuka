<?php echo e($slot); ?>

<?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>