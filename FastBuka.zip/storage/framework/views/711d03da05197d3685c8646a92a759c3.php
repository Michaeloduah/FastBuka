

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>All Categories</strong></h1>
        <div class="m-4 ">
            <a href="<?php echo e(route('vendor.dashboard.category.create')); ?>"><button class="btn btn-outline-info btn-sm"><i
                        class="bi bi-plus"></i> Add New Category</button></a>
        </div>
        <table id="myTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">Category Name</th>
                    <th scope="col">Image</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background: none">
                        <td> <?php echo e($category->name); ?> </td>
                        <td> <img src="<?php echo e(asset('storage/' . $category->image)); ?>" width="30%" class="img-fluid"
                                alt=""> </td>
                        <td>
                            <a href="<?php echo e(route('vendor.dashboard.category.show', $category->id)); ?>"><button
                                    class="btn btn-sm btn-outline-success m-1"><i class="bi bi-pencil-square"></i>More Info</button></a>
                            <a href="<?php echo e(route('vendor.dashboard.category.edit', $category->id)); ?>"><button
                                    class="btn btn-sm btn-outline-info m-1"><i class="bi bi-pencil-square"></i>Edit</button></a>
                            <a href="<?php echo e(route('vendor.dashboard.category.destroy', $category->id)); ?>"><button
                                    class="btn btn-sm btn-outline-danger m-1"><i class="bi bi-trash"></i>Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\vendors\category\index.blade.php ENDPATH**/ ?>