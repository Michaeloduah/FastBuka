

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">User Dashboard</h1>
        <h3>Your Cart</h3>

        <div class="my-5">
            <?php if(count($cartitems) <= 0): ?>
            <h1>Your Cart is empty</h1>
        <?php else: ?>
            
                <h1>Your Cart</h1>
                <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p>Product Name: <?php echo e($cartitem->food->name); ?></p>
                    <p>Description: <?php echo e($cartitem->food->description); ?></p>
                    <p>Images:</p>
                    <?php $__currentLoopData = $cartitem->food->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="thumbnail m-5" width="10%" src="<?php echo e(asset('storage/images/foods/' . $image)); ?>"
                            alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <p>Price: <?php echo e($cartitem->food->price); ?></p>
                    <p>Discount: <?php echo e($cartitem->food->discount); ?></p>
                    <p>Preparation time: <?php echo e($cartitem->food->processing_time); ?></p>

                    
                    <?php if($errors->has('total_amount')): ?>
                        <span class="error">
                            <span class="section-subtitle"
                                style="margin-inline: 0px"><?php echo e($errors->first('total_amount')); ?></span>
                        </span>
                    <?php endif; ?>

                    
                    <a href="<?php echo e(route('user.dashboard.food.details', $cartitem->food->id)); ?>"><button
                        class="btn btn-sm btn-outline-success m-1"><i class="bi bi-pencil-square"></i>More
                        Details</button></a>
                    <a href="<?php echo e(route('user.dashboard.cart.destroy', $cartitem->id)); ?>"><button
                        class="btn btn-sm btn-outline-danger m-1"><i class="bi bi-trash"></i>Delete</button></a>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="hidden" name="user_id" id="user_id" value="<?php echo e(auth()->user()->id); ?>">
                <input type="hidden" name="order_number" id="order_number">
                <?php if($errors->has('order_number')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('order_number')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="status" id="status" value="Pending">
                <?php if($errors->has('status')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('status')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="payment_method" id="payment_method" value="Pending">
                <?php if($errors->has('payment_method')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('payment_method')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="payment_status" id="payment_status" value="Pending">
                <?php if($errors->has('payment_status')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('payment_status')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="shipping_address" id="shipping_address" value="Pending">
                <?php if($errors->has('shipping_address')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('shipping_address')); ?></span>
                    </span>
                <?php endif; ?>

                <button class="btn btn-sm btn-outline-info mt-3" type="submit"><a class="text-decoration-none" href="<?php echo e(route('user.dashboard.cart.confirm')); ?>">Place Order</a></button>
            
        <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\users\cart\index.blade.php ENDPATH**/ ?>