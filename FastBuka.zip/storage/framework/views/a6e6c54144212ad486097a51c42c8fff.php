

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>Vendor Dashboard</strong></h1>
        <h3 class=""><strong>Add Foods</strong></h3>
        <div class="my-5">

            <form method="POST" action="<?php echo e(route('vendor.dashboard.food.store')); ?>" enctype="multipart/form-data"
                id="myForm">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="category" class="form-label">Category:</label>
                    <select class="form-select" name="category_id" id="category" value=<?php echo e(old('category')); ?>>
                        <option>Select Your Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($category->id); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if($errors->has('category')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('category')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Food Name:</label>
                    <input type="text" name="name" class="form-control" id="name" value=<?php echo e(old('name')); ?>>
                </div>
                <?php if($errors->has('name')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('name')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="description" class="form-label">Description:</label>
                    <textarea class="form-control" name="description" id="description" rows="3" value=<?php echo e(old('description')); ?>></textarea>
                </div>
                <?php if($errors->has('description')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('description')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="image[]" class="form-label">Image:</label>
                    <input type="file" name="image[]" class="form-control" id="image[]" multiple required>
                </div>
                <?php if($errors->has('image[]')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('image[]')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="price" class="form-label">Price:</label>
                    <input type="number" name="price" class="form-control" id="price" min="0"
                        value=<?php echo e(old('price')); ?>>
                </div>
                <?php if($errors->has('price')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('price')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="discount" class="form-label">Discount:</label>
                    <input type="number" name="discount" class="form-control" id="discount" min="0"
                        value=<?php echo e(old('discount')); ?>>
                </div>
                <?php if($errors->has('discount')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('discount')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="processing_time" class="form-label">Preparation Time (Minutes):</label>
                    <input type="number" name="processing_time" class="form-control" id="processing_time" min="0"
                        value=<?php echo e(old('processing_time')); ?>>
                </div>
                <?php if($errors->has('processing_time')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('processing_time')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="ready_made" class="form-label">Ready Made:</label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="ready_made" value="Yes" id="ready_made1">
                        <label class="form-check-label" for="ready_made1">
                            Yes
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="ready_made" value="No" id="ready_made2">
                        <label class="form-check-label" for="ready_made2">
                            No
                        </label>
                    </div>
                </div>
                <?php if($errors->has('ready_made')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('ready_made')); ?></span>
                    </span>
                <?php endif; ?>



                <button class="btn btn-sm btn-outline-info mt-3" type="submit">Create Food</button>

            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\vendors\food\create.blade.php ENDPATH**/ ?>