

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Vendor Dashboard</h1>
        <h3 class="text-center">Create a New Food Categories</h3>

        <div class="my-5">
            
            <form enctype="multipart/form-data" action="<?php echo e(route('vendor.dashboard.category.store')); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <label for="name" class="form-label">Category Name: </label>
                <input type="text" name="name" id="name" class="form-control"
                    required>
                <?php if($errors->has('name')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('name')); ?></span>
                    </span>
                <?php endif; ?>

                <label for="image" class="form-label">Image: </label>
                <input type="file" name="image" id="image" value="Pending" class="form-control">
                <?php if($errors->has('image')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('image')); ?></span>
                    </span>
                <?php endif; ?>

                <button class="btn btn-sm btn-outline-info mt-3" type="submit">Create Category</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\vendors\category\create.blade.php ENDPATH**/ ?>