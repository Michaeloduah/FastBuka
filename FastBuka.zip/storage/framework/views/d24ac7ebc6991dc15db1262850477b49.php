

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Users Dashboard</h1>
        <h3 class="text-center">Edit Profile</h3>

        <div class="my-5">
            <form enctype="multipart/form-data" action="<?php echo e(route('user.dashboard.updateprofile', auth()->user()->id)); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="InputName" class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-control" id="InputName">
                </div>
                <?php if($errors->has('name')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('name')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="InputEmail" class="form-label">Email Address</label>
                    <input type="email" name="email" class="form-control" id="InputEmail">
                </div>
                <?php if($errors->has('email')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('email')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="InputPhone" class="form-label">Phone Number</label>
                    <input type="tel" name="phone" class="form-control" id="InputPhone">
                </div>
                <?php if($errors->has('phone')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('phone')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="InputAddress" class="form-label">Address</label>
                    <input type="text" name="address" class="form-control" id="InputAddress">
                </div>
                <?php if($errors->has('address')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('address')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="InputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="InputPassword1">
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('password')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="InputConfirmPassword1" class="form-label">Confirm Password</label>
                    <input type="password" name="confirmpassword" class="form-control" id="InputConfirmPassword1">
                </div>
                <?php if($errors->has('confirmpassword')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('confirmpassword')); ?></span>
                    </span>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="InputImage" class="form-label">Confirm Password</label>
                    <input type="file" name="image" class="form-control" id="InputImage">
                </div>
                <?php if($errors->has('image')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('image')); ?></span>
                    </span>
                <?php endif; ?>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views/dashboard/users/editprofile.blade.php ENDPATH**/ ?>