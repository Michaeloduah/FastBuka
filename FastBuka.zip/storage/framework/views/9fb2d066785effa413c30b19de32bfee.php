

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">User Dashboard</h1>
        <h3>Your Cart</h3>

        <div class="my-5">
            <?php if(count($wishlists) <= 0): ?>
                <h1>Your Wishlist is empty</h1>
            <?php else: ?>
                
                <h1>Your Cart</h1>
                <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p>Product Name: <?php echo e($wishlist->food->name); ?></p>
                    <p>Description: <?php echo e($wishlist->food->description); ?></p>
                    <p>Images:</p>
                    <?php $__currentLoopData = $wishlist->food->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="thumbnail m-5" width="10%" src="<?php echo e(asset('storage/images/foods/' . $image)); ?>"
                            alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <p>Discount: <?php echo e($wishlist->food->discount); ?></p>

                    <a href="<?php echo e(route('user.dashboard.food.details', $wishlist->food->id)); ?>"><button
                            class="btn btn-sm btn-outline-success m-1"><i class="bi bi-pencil-square"></i>More
                            Details</button></a>
                    <a href="<?php echo e(route('user.dashboard.wishlist.destroy', $wishlist->id)); ?>"><button
                            class="btn btn-sm btn-outline-danger m-1"><i class="bi bi-trash"></i>Delete</button></a>
                    <form action="<?php echo e(route('user.dashboard.cart.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($wishlist->food->id); ?>" name="food_id">
                        <input type="hidden" value="1" name="quantity">
                        <button class="btn btn-sm btn-outline-primary m-1"><i class="bi bi-pencil-square"></i>Add to
                            Cart</button>
                    </form>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <input type="hidden" name="user_id" id="user_id" value="<?php echo e(auth()->user()->id); ?>">
                <input type="hidden" name="order_number" id="order_number">
                <?php if($errors->has('order_number')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('order_number')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="status" id="status" value="Pending">
                <?php if($errors->has('status')): ?>
                    <span class="error">
                        <span class="section-subtitle" style="margin-inline: 0px"><?php echo e($errors->first('status')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="payment_method" id="payment_method" value="Pending">
                <?php if($errors->has('payment_method')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('payment_method')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="payment_status" id="payment_status" value="Pending">
                <?php if($errors->has('payment_status')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('payment_status')); ?></span>
                    </span>
                <?php endif; ?>

                <input type="hidden" name="shipping_address" id="shipping_address" value="Pending">
                <?php if($errors->has('shipping_address')): ?>
                    <span class="error">
                        <span class="section-subtitle"
                            style="margin-inline: 0px"><?php echo e($errors->first('shipping_address')); ?></span>
                    </span>
                <?php endif; ?>

                <button class="btn btn-sm btn-outline-info mt-3" type="submit">Place Order</button>
                
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\users\wishlist\index.blade.php ENDPATH**/ ?>