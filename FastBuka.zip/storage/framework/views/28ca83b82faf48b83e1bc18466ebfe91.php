

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>All Orders</strong></h1>
        <table id="myTable" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th scope="col">Date/Time Ordered</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Customer Phone Number</th>
                    <th scope="col">Order Number</th>
                    <th scope="col">Order Status</th>
                    <th scope="col">Total Amount</th>
                    <th scope="col">Shipping Address</th>
                    <th scope="col">Payment Method</th>
                    <th scope="col">Payment Status</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="background: none">
                        <td> <?php echo e($order->created_at); ?> </td>
                        <td> <?php echo e($order->user->name); ?> </td>
                        <td> <?php echo e($order->user->phone); ?> </td>
                        <td> <?php echo e($order->order_number); ?> </td>
                        <td> <?php echo e($order->status); ?> </td>
                        <td> <?php echo e($order->total_amount); ?> </td>
                        <td> <?php echo e($order->shipping_address); ?> </td>
                        <td> <?php echo e($order->payment_method); ?> </td>
                        <td> <?php echo e($order->payment_status); ?> </td>
                        <td>
                            <a href="#"><button class="btn btn-sm btn-outline-success m-1"><i
                                        class="bi bi-pencil-square"></i>More Info</button></a>
                            <a href="#"><button class="btn btn-sm btn-outline-info m-1"><i
                                        class="bi bi-pencil-square"></i>Edit</button></a>
                            <a href="#"><button class="btn btn-sm btn-outline-danger m-1"><i
                                        class="bi bi-trash"></i>Delete</button></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\vendors\order\index.blade.php ENDPATH**/ ?>