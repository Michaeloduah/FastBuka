

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>User Dashboard</strong></h1>
        <h3 class=""><strong>All Available Foods</strong></h3>

        <form action="<?php echo e(route('user.dashboard.food.search')); ?>" method="GET" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input name="keyword" type="text" placeholder="Search">
            <button type="submit">Search</button>
        </form>
        <div class="my-5">
            <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><span class="fw-bolder">Food Category:</span> <?php echo e($food->category->name); ?></< /p>
                <p><span class="fw-bolder">Name:</span> <?php echo e($food->name); ?></p>
                <p><span class="fw-bolder">Description:</span> <?php echo e($food->description); ?></p>
                <p><span class="fw-bolder">Price:</span> <?php echo e($food->price); ?></p>
                <p><span class="fw-bolder">Discount:</span> <?php echo e($food->discount); ?></p>
                <p><span class="fw-bolder">Images</p>
                <?php $__currentLoopData = $food->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="thumbnail m-5" width="15%" src="<?php echo e(asset('storage/images/foods/' . $image)); ?>"
                        alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('user.dashboard.food.details', $food->id)); ?>"><button
                        class="btn btn-sm btn-outline-success m-1"><i class="bi bi-pencil-square"></i>More
                        Details</button></a>
                <form action="<?php echo e(route('user.dashboard.cart.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($food->id); ?>" name="food_id">
                    <input type="hidden" value="1" name="quantity">
                    <button class="btn btn-sm btn-outline-primary m-1"><i class="bi bi-pencil-square"></i>Add to
                        Cart</button>
                </form>
                <form action="<?php echo e(route('user.dashboard.wishlist.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($food->id); ?>" name="food_id">
                    <button class="btn btn-sm btn-outline-primary m-1"><i class="bi bi-pencil-square"></i>Add to
                        Favourite</button>
                </form>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\users\food\index.blade.php ENDPATH**/ ?>