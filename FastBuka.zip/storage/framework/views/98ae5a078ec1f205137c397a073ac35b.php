

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">Users Dashboard</h1>
        <h3>Your Profile</h3>
        <ul>
            <li>Full Name: <?php echo e($user->name); ?></li>
            <li>Email Address: <?php echo e($user->email); ?></li>
            <li>Phone Number: <?php echo e($user->phone); ?></li>
            <li>Address: <?php echo e($user->address); ?></li>
            <img src="<?php echo e(asset('storage/' . $user->image)); ?>" width="15%" alt="" class="img-fluid">
        </ul>
        <hr>
        <h3>Features</h3>
        <ol>
            <li><a class="text-decoration-none" href="<?php echo e(route('profile')); ?>">Profile</a></li>
            <span>Products/Food</span>
            <li><a class="text-decoration-none" href="<?php echo e(route('user.dashboard.food.index')); ?>">All Foods</a></li>
            <span>Cart/Cart Items</span>
            <li><a href="<?php echo e(route('user.dashboard.cart.index')); ?>" class="text-decoration-none">My Cart</a></li>
            <span>Wishlist/Favourites</span>
            <li><a href="<?php echo e(route('user.dashboard.wishlist.index')); ?>" class="text-decoration-none">My Favourite</a></li>
        </ol>

        <form action="<?php echo e(route('logout')); ?> " method="POST">
            <?php echo csrf_field(); ?>
            <button class="btn btn-sm btn-outline-danger"> Logout</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views/dashboard/users/dashboard.blade.php ENDPATH**/ ?>