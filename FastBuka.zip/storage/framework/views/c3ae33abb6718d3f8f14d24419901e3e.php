

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center"><strong>Vendor Dashboard</strong></h1>
        <h3 class=""><strong>Food More Detail</strong></h3>

        <div class="my-5">
            <p><span class="fw-bolder">Food Category:</span> <?php echo e($food->category->name); ?></p>
            <p><span class="fw-bolder">Name:</span> <?php echo e($food->name); ?></p>
            <p><span class="fw-bolder">Description:</span> <?php echo e($food->description); ?></p>
            <p><span class="fw-bolder">Price:</span> <?php echo e($food->price); ?></p>
            <p><span class="fw-bolder">Discount:</span> <?php echo e($food->discount); ?></p>
            <p><span class="fw-bolder">Images</p>
            <?php $__currentLoopData = $food->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img class="thumbnail m-5" width="15%" src="<?php echo e(asset('storage/images/foods/' . $image)); ?>"
                    alt="">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.vendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\vendors\food\show.blade.php ENDPATH**/ ?>