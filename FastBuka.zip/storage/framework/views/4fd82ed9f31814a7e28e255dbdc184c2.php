

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="text-center">User Dashboard</h1>
        <h3>Confirm Order</h3>

        <form class="my-5" action="<?php echo e(route('user.dashboard.order.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($cartitem->food->name); ?></p>
                <img class="thumbnail m-5" width="10%"
                    src="<?php echo e(asset('storage/images/foods/' . $cartitem->food->images[0])); ?>" alt=""><br>
                <p>Price: <?php echo e($cartitem->food->price); ?></p>
                <label for="Quantity" class="form-label">Quantity: <?php echo e($cartitem->quantity); ?></label>
                
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <label for="Address" class="form-label">Address:</label>
            <input class="form-control" type="text" name="shipping_address">
            <input type="hidden" name="order_number">
            <input type="hidden" name="total_amount">
            <button class="btn btn-sm btn-outline-info mt-3" type="submit">Place Order</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views\dashboard\users\cart\confirm.blade.php ENDPATH**/ ?>