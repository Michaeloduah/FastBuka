

<?php $__env->startSection('content'); ?>
    
    <section id="product-page" class="product-page container mt-5">
        <div class="container product-page-hero" data-aos="fade-up">
            <div class="food-details">
                <div class="row mb-5">
                    <div class="col-12 col-md-3 col-lg-3">
                        <div class="food-detalis-img">
                            <img src="<?php echo e(asset('storage/images/foods/' . $food->images[0])); ?>" alt=""
                                class="img-fluid rounded" />
                        </div>
                    </div>

                    <div class="col-12 col-md-9 col-lg-9">
                        <div class="food-details-info px-3">
                            <div class="d-flex justify-content-between">
                                <h3 class="fw-bolder"><?php echo e($food->name); ?></h3>
                                <select class="form-select form-select-sm fw-bold restaurant"
                                    aria-label="Small select example" disabled>
                                    <option selected>
                                        <?php echo e($food->user->name); ?> <i class="bi bi-chevron-down"></i>
                                    </option>
                                </select>
                            </div>
                            <p class="mt-4">
                                <?php echo e($food->description); ?>

                            </p>
                            <h1 class="price fs-3">N<?php echo e($food->price); ?><sup>.00</sup></h1>
                            <div class="d-flex mt-4 ">
                                <?php if($inCart): ?>
                                    <?php
                                        $foundCartItem = $cartitems->firstWhere('food_id', $food->id); // Assuming $food->id is the ID you want to match
                                    ?>

                                    <?php if($foundCartItem): ?>
                                        <div class="product-quantity d-flex justify-content-between  me-3"
                                            style="width: 30%;">
                                            <a href="<?php echo e(route('user.dashboard.cart.decrease', $foundCartItem->id)); ?>"><button
                                                    class="btn btn-lg button1">-</button></a>
                                            <input class="form-control border border-0 text-center fs-5" type="text"
                                                value="<?php echo e($foundCartItem->quantity); ?>" readonly />
                                            <a href="<?php echo e(route('user.dashboard.cart.increase', $foundCartItem->id)); ?>"><button
                                                    class="btn btn-lg button2">+</button></a>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if($inCart): ?>
                                    <?php
                                        $foundCartItem = $cartitems->firstWhere('food_id', $food->id); // Assuming $food->id is the ID you want to match
                                    ?>

                                    <?php if($foundCartItem): ?>
                                        <a href="<?php echo e(route('user.dashboard.cart.destroy', $foundCartItem->id)); ?>">
                                            <button class="btn fw-bold cart-added">Added to cart</button>
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <form action="<?php echo e(route('user.dashboard.cart.store')); ?>" method="POST" class="">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($food->id); ?>" name="food_id">
                                        <input type="hidden" value="1" name="quantity">
                                        <button class="btn fw-bold cart-add"></i>Add to
                                            Cart</button>
                                    </form>
                                <?php endif; ?>
                                <i class="bi bi-heart mx-3 my-auto fs-4"></i>
                                
                            </div>
                            <p class="mt-3"><span>Food Category:</span> <?php echo e($food->category->name); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oduah\OneDrive\Documents\Website\FastBuka\resources\views/dashboard/users/food/show.blade.php ENDPATH**/ ?>